# AULALOGIC

Sistema de Seguimiento del Rendimiento Académico

Variante E — Nota mínima de aprobación: 15/20

Completa este archivo con tu información y las instrucciones de ejecución.
