# Casos de prueba

Documenta aquí entrada, resultado esperado, resultado obtenido y estado para CP01–CP08.
