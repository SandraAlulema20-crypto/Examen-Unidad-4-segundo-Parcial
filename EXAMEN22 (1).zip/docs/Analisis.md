# ANÁLISIS DEL PROBLEMA — AULALOGIC

## 1. Introducción
AulaLogic es un sistema de apoyo académico diseñado para registrar, consultar y procesar las calificaciones de los estudiantes. Su finalidad es organizar la información y calcular automáticamente los promedios y el estado académico.

## 2. Planteamiento del problema
El registro manual de calificaciones puede provocar errores al transcribir datos, realizar operaciones aritméticas y determinar si un estudiante aprueba. Además, buscar registros y elaborar reportes puede tomar tiempo y generar información desorganizada.

## 3. Objetivo
Desarrollar un sistema que permita registrar estudiantes, validar sus calificaciones, buscar información por código, calcular promedios y generar reportes con el estado académico correspondiente.

## 4. Entrada
El programa recibe:
- Código del estudiante.
- Nombre completo.
- Primera calificación.
- Segunda calificación.
- Tercera calificación.
- Opción seleccionada del menú.

## 5. Proceso
El sistema realiza las siguientes operaciones:
- Validación de datos: comprueba que las calificaciones estén entre 0 y 20 y que los campos requeridos sean válidos.
- Registro de estudiantes: almacena el código, nombre y las tres calificaciones.
- Búsqueda por código: localiza al estudiante mediante su identificador.
- Cálculo de promedios: suma las tres calificaciones y divide el resultado para tres.
- Determinación del estado académico: asigna APROBADO si el promedio es igual o superior a 15; de lo contrario, REPROBADO.
- Generación de reportes: presenta los datos, las calificaciones, el promedio y el estado.
- Almacenamiento de información: permite conservar los registros en archivos de texto.

## 6. Salida
El sistema muestra:
- Datos del estudiante.
- Calificaciones registradas.
- Promedio calculado.
- Estado: APROBADO o REPROBADO.
- Reporte académico general.

## 7. Criterios de aprobación
- Calificaciones permitidas: de 0 a 20.
- Promedio mínimo de aprobación: 15.
- De 15 a 20: APROBADO.
- Menor a 15: REPROBADO.

## 8. Herramientas y estructuras utilizadas
- Java: lenguaje utilizado para desarrollar la lógica del sistema.
- Clases: organizan el programa y definen sus componentes.
- Objetos: representan a cada estudiante.
- Arreglos y ArrayList: permiten almacenar y gestionar colecciones de datos.
- Ciclos: facilitan recorrer registros y repetir opciones del menú.
- Archivos de texto: permiten guardar y recuperar la información.

## 9. Conclusión
AulaLogic ayuda a organizar los registros académicos y reduce errores en el cálculo de promedios y la clasificación de resultados. En su desarrollo se aplican conocimientos de Java, programación orientada a objetos, estructuras de datos, ciclos, validaciones y manejo de archivos.

## Resultados de los datos proporcionados
| Código | Estudiante | Promedio | Estado |
|---|---|---:|---|
| 001 | Ana Torres | 17,00 | APROBADO |
| 002 | Luis Mena | 15,00 | APROBADO |
| 003 | Rosa Paredes | 13,00 | REPROBADO |
| 004 | Mario Silva | 19,00 | APROBADO |
| 005 | Elena Cruz | 14,67 | REPROBADO |

Nota: Elena Cruz obtiene 14,67 (44 ÷ 3), por lo que no alcanza el promedio mínimo de 15.
