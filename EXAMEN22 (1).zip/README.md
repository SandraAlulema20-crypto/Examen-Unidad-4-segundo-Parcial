# 🎓 AULALOGIC
## Sistema de Seguimiento del Rendimiento Académico

<p align="center">
  <img src="https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white" alt="Java">
  <img src="https://img.shields.io/badge/NetBeans-1B6AC6?style=for-the-badge&logo=apachenetbeanside&logoColor=white" alt="NetBeans">
  <img src="https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white" alt="GitHub">
</p>

---

## 🏛️ Universidad Técnica de Ambato

- **Facultad:** Ingeniería en Sistemas, Electrónica e Industrial (FISEI)
- **Carrera:** Ingeniería de Software
- **Asignatura:** Algoritmos y Lógica de Programación
- **Proyecto:** Examen Práctico Integrador
- **Variante asignada:** E

---

## 📖 Sobre el proyecto

AulaLogic es un sistema desarrollado en Java que permite gestionar la información académica de los estudiantes mediante el registro, consulta, procesamiento y almacenamiento de calificaciones.

Su funcionamiento se realiza mediante consola y permite generar reportes para conocer el rendimiento académico del curso.

## 🎯 Objetivos

- Administrar registros de estudiantes.
- Procesar las calificaciones automáticamente.
- Generar indicadores del rendimiento académico.
- Conservar la información mediante archivos de texto.
- Aplicar programación orientada a objetos.

## ✨ Funcionalidades principales

| Funcionalidad | Descripción |
|---|---|
| 📝 Registro | Ingreso de estudiantes y calificaciones |
| 📋 Listado | Visualización de estudiantes registrados |
| 🔎 Búsqueda | Consulta mediante código |
| 🧮 Promedios | Cálculo de notas individuales |
| 📊 Reportes | Estadísticas del rendimiento académico |
| 💾 Archivos | Guardado y recuperación de información |
| ↕️ Ordenamiento | Clasificación por promedio |

## 📌 Variante E – Criterio de aprobación

<p align="center">
  <img src="https://img.shields.io/badge/NOTA%20MÍNIMA-15%2F20-success?style=for-the-badge" alt="Nota mínima 15 sobre 20">
</p>

| Promedio | Estado |
|---|---|
| 15 – 20 | ✅ APROBADO |
| Menor a 15 | ❌ REPROBADO |

Las calificaciones válidas están comprendidas entre **0 y 20**. El promedio se calcula sumando las tres calificaciones y dividiendo el resultado para tres.

## 🛠️ Herramientas utilizadas

- ☕ Java
- 💻 Apache NetBeans
- 🌐 GitHub
- 📁 Archivos de texto

## 📂 Organización del proyecto

```text
Examen-ALP-Apellido-Nombre
┣ 📂 src
┃ ┣ 📜 Main.java
┃ ┣ 📜 Estudiante.java
┃ ┣ 📜 GestionAcademica.java
┃ ┗ 📜 GestorArchivos.java
┣ 📂 datos
┃ ┗ 📜 estudiantes.txt
┣ 📂 docs
┃ ┣ 📜 Analisis.md
┃ ┗ 📜 CasosDePrueba.md
┣ 📂 evidencias
┃ ┗ 🖼️ Ejecucion.png
┗ 📜 README.md
```

## ▶️ Instalación y ejecución

1. Clonar o descargar el repositorio.
2. Abrir el proyecto en Apache NetBeans.
3. Verificar que los archivos Java estén dentro del paquete o carpeta `src`.
4. Comprobar que la ruta del archivo de datos sea correcta.
5. Ejecutar `Main.java`.
6. Seleccionar una opción del menú principal.

## 🧪 Casos de prueba

La documentación de los ocho casos de prueba se encuentra en [`docs/CasosDePrueba.md`](docs/CasosDePrueba.md).

- CP01 – Registro correcto.
- CP02 – Código duplicado.
- CP03 – Calificación fuera del rango.
- CP04 – Promedio igual a 15.
- CP05 – Búsqueda de estudiante existente.
- CP06 – Búsqueda de estudiante inexistente.
- CP07 – Reporte sin estudiantes.
- CP08 – Guardado y recuperación de datos.

## 👨‍🎓 Autor

- **Nombre:** [Nombres y apellidos]
- **Universidad:** Universidad Técnica de Ambato
- **Carrera:** Ingeniería de Software

---

<p align="center">
  🎓 <strong>AULALOGIC</strong><br>
  Gestión académica mediante programación y tecnología.<br>
  Universidad Técnica de Ambato · 2026
</p>
